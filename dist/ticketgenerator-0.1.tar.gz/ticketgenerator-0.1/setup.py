from distutils.core import setup
setup(
  name = 'ticketgenerator',
  packages = ['ticketgenerator'], # this must be the same as the name above
  version = '0.1',
  description = 'Housie Ticket Generation',
  author = 'ksgsarma',
  author_email = 'ksgsarma5@gmail.com',
  url = 'https://github.com/ksgsarma/Housie_PyPi.git',
  keywords = ['ticket'],
  classifiers = [],
)
